from flask_app import app
from flask import render_template, redirect, request, flash, session
from flask_app.models.user_model import User
from flask_app.models.car_model import Car

@app.route("/add_car")
def new_car():
  if "user_id" not in session:
    return("/")
  return render_template("new.html")


@app.route("/insert_your_car", methods=["POST"])
def insert_new_car():
  if "user_id" not in session:
    return("/")
  if not Car.validator(request.form):
    return redirect("/add_car")
  car_data = {
    **request.form,
    "user_id": session["user_id"]
  }
  Car.create(car_data)
  return redirect("/")

@app.route("/show/<int:id>")
def show_one_car(id):
  if "user_id" not in session:
    return("/")
  data = {
    "id": session["user_id"]
  }
  logged_user = User.get_by_id(data)
  this_car = Car.get_by_id({"id":id})
  all_cars = Car.get_all()
  return render_template("show.html", all_cars=all_cars, this_car=this_car, logged_user=logged_user)

@app.route("/edit/<int:id>")
def edit_show(id):
  if "user_id" not in session:
    return("/")
  data = {
    "id": id
  }
  one_car = Car.get_by_id(data)
  return render_template("edit.html", one_car=one_car)

@app.route("/users/<int:id>") #purchases page (my cars link)
def my_cars(id): #pass id to class method from route <int:id>
  if "user_id" not in session:
    return("/")
  data = {
    "id": session["user_id"]
  }
  logged_user = User.get_by_id(data)
  this_car = Car.get_by_id({"id":id})
  my_purchases = Car.select_all(data)
  count = Car.count_cars_by_show_id(id) #this is getting the count with the id
  all_buys = Car.show_all_purchases(data)
  return render_template("mycars.html",all_buys=all_buys, count=count, my_purchases=my_purchases, this_car=this_car, logged_user=logged_user)

@app.route("/my_purchases", methods=["POST"])
def add_new_purchase():
  data = {
    "user_id": session["user_id"],
    "car_id": request.form["purchase_id"]
  }
  Car.data_into_purchase(data)
  return redirect(f"/users/{session['user_id']}")

@app.route("/update/<int:id>", methods=["POST"])
def update_show(id):
  if "user_id" not in session:
    return("/")
  if not Car.validator(request.form):
    return redirect(f"/edit/{id}")
  data = {
    "id":id,
    **request.form
  }
  Car.update(data)
  return redirect("/dashboard")

@app.route("/cars/<int:id>/delete")
def del_show(id):
  if "user_id" not in session:
    return redirect("/")
  data = {
    "id": id
  }
  this_car = Car.get_by_id(data)
  if not this_car.user_id == session["user_id"]: #person who is logged in
    flash("Hey, not yours, not gonna delete it")
    return redirect("/dashboard")
  Car.delete({"id":id})
  return redirect("/dashboard")

