from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import DATABASE
from flask import flash
from flask_app.models import user_model
from flask_app.models import car_model

class Car:
  def __init__(self,data):
    self.id = data["id"]
    self.price = data["price"]
    self.model = data["model"]
    self.make = data["make"]
    self.year = data["year"]
    self.description = data["description"]
    self.created_at = data["created_at"]
    self.updated_at = data["updated_at"]
    self.user_id = data["user_id"]

  @classmethod
  def create(cls,data):
    query = """
    INSERT INTO cars (price, model, make, year, description, user_id)
    VALUES (%(price)s, %(model)s, %(make)s, %(year)s, %(description)s, %(user_id)s);
    """
    print("hihi")
    return connectToMySQL(DATABASE).query_db(query,data)

  @classmethod
  def get_all(cls):
    query = """
    SELECT * FROM cars JOIN users on cars.user_id = users.id
    """
    print("hihi")
    results = connectToMySQL(DATABASE).query_db(query)
    all_cars = []
    if results:
      for row in results:
        this_car = cls(row)
        user_data = {
          **row,
          "id": row["users.id"],
          "created_at": row["users.created_at"],
          "updated_at": row["updated_at"]
        }
        this_user = user_model.User(user_data)
        this_car.viewer = this_user
        all_cars.append(this_car)
    return all_cars

  @classmethod
  def get_by_id(cls,data):
    query = """
    SELECT * FROM cars JOIN users ON cars.user_id = users.id
    WHERE cars.id = %(id)s;
    """
    results = connectToMySQL(DATABASE).query_db(query,data)
    if results:
      this_car = cls(results[0])
      row = results[0]
      user_data = {
        **row,
        "id": row["users.id"],
        "created_at": row["users.created_at"],
        "updated_at": row["users.updated_at"]
      }
      this_user = user_model.User(user_data)
      this_car.viewer = this_user
      return this_car
    return False

  @classmethod
  def update(cls,data):
    query = """
    UPDATE cars SET price = %(price)s, model = %(model)s, make = %(make)s, year = %(year)s, description = %(description)s
    WHERE id = %(id)s;
    """
    return connectToMySQL(DATABASE).query_db(query,data)

  @classmethod
  def delete(cls,data):
    query = """
    DELETE FROM cars WHERE id = %(id)s;
    """
    return connectToMySQL(DATABASE).query_db(query,data)

  @classmethod
  def count_cars_by_show_id(cls, car_id): #this parameter brings in argument for def show_one countbylikes id
    data = {
      "car_id": car_id #this key gets a value of 5 (or whatever the id is)
    }                    # "show_id" matches %(show_id)s
    query = """
    SELECT count(user_id) as num FROM purchase WHERE car_id = %(car_id)s;
    """
    results = connectToMySQL(DATABASE).query_db(query,data)
    return results[0]["num"]

  @classmethod #many2many join. select each needed for div display
  def select_all(cls,data): 
    query = """
    SELECT DISTINCT first_name FROM cars
    LEFT JOIN purchase ON cars.id = purchase.cars_id
    JOIN users ON users.id = cars.user_id
    """
    results = connectToMySQL(DATABASE).query_db(query,data)
    return results

  @classmethod
  def show_all_purchases(cls,data):
    query = """
    SELECT * FROM users
    JOIN purchase on users.id = purchase.user_id
    JOIN cars ON cars.id = purchase.car_id
    """
    results = connectToMySQL(DATABASE).query_db(query,data)
    if results:
      cars = []
      for row in results:
        user = cls(row)
        data = {
          **row,
          "id": row["cars.id"],
          "created_at": row["cars.created_at"],
          "updated_at": row["cars.updated_at"]
        }
        this_car = car_model.Car(data)
        user.car = this_car
        cars.append(user)
        print("hihi")
        print(cars)
      return cars
    return []

    #insert data (show_id and user_id) into the likes table
  @classmethod
  def data_into_purchase(cls,data):
    query = """
    INSERT INTO purchase (user_id, car_id)
    VALUES (%(user_id)s, %(car_id)s)
    """
    return connectToMySQL(DATABASE).query_db(query,data)


  @staticmethod
  def validator(data):
    is_valid = True
    if data["price"]:
      if int(data["price"]) <= 0:
        flash("Your car is worth more than that!")
        is_valid = False
    if len(data["model"]) < 2:
      flash("Model field required to be 3 characters minimum")
      is_valid = False
    if len(data["make"]) < 2:
      flash("Make field required to be 3 characters minimum")
      is_valid = False
    if data["year"]:
      if int(data["year"]) <= 1950:
        flash("Sorry! Car is too old!")
        is_valid = False
    if len(data["description"]) < 2:
      flash("Description field required to be 3 characters minimum")
      is_valid = False
    return is_valid